## Pré-requisitos para o Deploy do Sistema STIHL AI

Para garantir um deploy bem-sucedido do sistema de Banco de Dados Inteligente STIHL com IA Autônoma no seu servidor DigitalOcean, é fundamental que os seguintes pré-requisitos de software e configurações de ambiente sejam atendidos.

### 1. Requisitos de Software no Servidor

O servidor DigitalOcean (Ubuntu 24.04 LTS) precisará ter os seguintes softwares instalados e configurados:

- **Python 3.11 ou superior:** O sistema é desenvolvido em Python e requer uma versão compatível. O Ubuntu 24.04 LTS já deve vir com uma versão recente do Python 3, mas é importante verificar.
- **pip:** O gerenciador de pacotes do Python, essencial para instalar as dependências da aplicação.
- **PostgreSQL Client Libraries:** Embora o banco de dados esteja no Supabase, a aplicação Flask precisará de bibliotecas cliente para se conectar a ele. Isso inclui `libpq-dev` (para Ubuntu/Debian) para o `psycopg2`.
- **Git:** Para clonar o repositório da aplicação.
- **Gunicorn:** Um servidor WSGI (Web Server Gateway Interface) para servir a aplicação Flask em produção.
- **Nginx:** Um servidor web de alta performance que atuará como proxy reverso para o Gunicorn, lidando com requisições HTTP/HTTPS e servindo arquivos estáticos.
- **Certbot (opcional, mas altamente recomendado):** Para automatizar a obtenção e renovação de certificados SSL/TLS gratuitos do Let's Encrypt, garantindo comunicação segura (HTTPS).
- **build-essential:** Pacotes essenciais para compilação de software, necessários para algumas dependências Python.

### 2. Variáveis de Ambiente Essenciais

As seguintes variáveis de ambiente são cruciais para o funcionamento correto da aplicação. Elas devem ser configuradas no ambiente do servidor onde a aplicação Flask será executada. **Nunca exponha essas chaves diretamente no código-fonte ou em repositórios públicos.**

- **`OPENAI_API_KEY`**: Sua chave de API da OpenAI. Esta chave é utilizada pelo motor de busca inteligente para processar consultas em linguagem natural e pela IA autônoma para análise de planilhas.
  - **Valor fornecido:** `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`

- **`SUPABASE_URL`**: A URL do seu projeto Supabase. É o endpoint principal para a API do Supabase.
  - **Valor fornecido:** `https://eclmgkajlhrstyyhejev.supabase.co`

- **`SUPABASE_ANON_KEY`**: A chave `anon` pública do seu projeto Supabase. Usada para acesso de leitura/escrita por clientes não autenticados (com RLS ativado, as permissões são controladas pelas políticas).
  - **Valor fornecido:** `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVjbG1na2FqbGhyc3R5eWhlamV2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY2ODgzNDAsImV4cCI6MjA3MjI2NDM0MH0.fvA7SpoofVp3iBqc4uYfQX49rp1MooLWfHC3uFM7-Bw`

- **`SUPABASE_SERVICE_KEY`**: A chave `service_role` secreta do seu projeto Supabase. Esta chave tem privilégios de superusuário e deve ser usada APENAS no backend (servidor) para operações que exigem acesso total, como a IA autônoma para construção do banco de dados.
  - **Valor fornecido:** `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVjbG1na2FqbGhyc3R5eWhlamV2Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1NjY4ODM0MCwiZXhwIjoyMDcyMjY0MzQwfQ.XvRgFhWYRXLDXn7kF8ys-hXGK04XDRHzkB3KeS3ktKo`

- **`DATABASE_URL`**: A URL de conexão direta com o banco de dados PostgreSQL do Supabase. Esta é a URL que a aplicação Flask usará para se conectar ao banco de dados.
  - **Valor fornecido:** `postgresql://postgres:rBVm2mIQds3PneOy@db.eclmgkajlhrstyyhejev.supabase.co:5432/postgres`

- **`FLASK_ENV`**: Define o ambiente do Flask. Deve ser `production` em um ambiente de produção para desativar o modo de depuração e otimizar a performance.
  - **Valor sugerido:** `production`

- **`SECRET_KEY`**: Uma chave secreta para sessões do Flask e outras operações de segurança. Deve ser uma string longa e aleatória.
  - **Valor sugerido:** Gerar uma string aleatória (ex: `python -c 'import os; print(os.urandom(24).hex())'`)

### 3. Dependências Python da Aplicação

As dependências Python específicas da aplicação estão listadas no arquivo `requirements.txt` gerado. Elas serão instaladas dentro de um ambiente virtual para isolamento.

### 4. Credenciais de Acesso ao Servidor

Você precisará de acesso SSH ao seu droplet DigitalOcean com permissões de `sudo` para realizar as instalações e configurações necessárias.

- **IP Público do Servidor:** `143.198.33.61`
- **Usuário:** `root` (ou um usuário com permissões sudo)
- **Chave SSH:** A chave SSH que você usa para acessar o servidor. (A chave fornecida no `pasted_content.txt` parece ser uma chave SSH gerada localmente, não a chave pública que você adicionaria ao DigitalOcean. Certifique-se de usar a chave pública correta para acesso ao droplet.)

Com estes pré-requisitos em mente, podemos prosseguir para a próxima fase: a configuração do Supabase.

## 2. Configuração do Supabase

Esta seção detalha os passos necessários para configurar o banco de dados no Supabase, que servirá como o backend persistente para o sistema STIHL AI. Certifique-se de ter acesso ao painel do seu projeto Supabase e as credenciais necessárias (URL do projeto, chaves `anon` e `service_role`, e a URL de conexão direta com o banco de dados PostgreSQL).

### 2.1 Acessando o Painel do Supabase

1.  Navegue até o site do Supabase: [https://supabase.com/](https://supabase.com/)
2.  Faça login na sua conta.
3.  No painel, selecione o projeto `Bot consultor comercial` (ID: `eclmgkajlhrstyyhejev`).

### 2.2 Obtendo Credenciais do Banco de Dados

Dentro do painel do seu projeto Supabase, vá para `Project Settings` > `Database`. Anote as seguintes informações, que serão usadas para configurar a aplicação Flask:

-   **Host:** `db.eclmgkajlhrstyyhejev.supabase.co`
-   **Port:** `5432`
-   **User:** `postgres`
-   **Password:** `rBVm2mIQds3PneOy`
-   **Database Name:** `postgres`

Você também pode encontrar a `Connection String` completa, que é:
`postgresql://postgres:rBVm2mIQds3PneOy@db.eclmgkajlhrstyyhejev.supabase.co:5432/postgres`

### 2.3 Executando os Scripts SQL

Os scripts SQL fornecidos criarão a estrutura completa do banco de dados, as funções especializadas para a IA, inserirão dados de exemplo e configurarão as políticas de segurança (Row Level Security - RLS). Você pode executar esses scripts de algumas maneiras:

#### Opção 1: Usando o SQL Editor do Supabase (Recomendado para iniciantes)

1.  No painel do Supabase, clique em `SQL Editor` no menu lateral.
2.  Abra cada um dos arquivos SQL (`01_create_tables.sql`, `02_create_functions.sql`, `03_insert_data.sql`, `04_security_rls.sql`) que foram gerados e entregues a você.
3.  Copie o conteúdo de cada arquivo, um por um, e cole no editor SQL do Supabase.
4.  Clique no botão `RUN` para executar o script. Certifique-se de que cada script seja executado com sucesso antes de passar para o próximo.

    **Ordem de Execução:**
    1.  `01_create_tables.sql` (Criação das tabelas)
    2.  `02_create_functions.sql` (Criação das funções SQL para IA)
    3.  `03_insert_data.sql` (Inserção dos dados de exemplo)
    4.  `04_security_rls.sql` (Configuração de segurança e RLS)

#### Opção 2: Usando `psql` (Linha de Comando) - RECOMENDADO PARA DADOS CSV

Se você tiver o cliente `psql` instalado localmente ou no seu servidor DigitalOcean, pode executar os scripts diretamente da linha de comando. Esta é a opção recomendada quando você tem dados normalizados em arquivos CSV.

**Pré-requisitos para importação CSV:**
1. Arquivos CSV organizados e validados
2. Arquivos CSV transferidos para o servidor no diretório `/tmp/csv_data/`
3. Permissões corretas configuradas

**Preparação dos arquivos CSV no servidor:**

```bash
# Criar diretório para os CSVs no servidor
sudo mkdir -p /tmp/csv_data/
sudo chown postgres:postgres /tmp/csv_data/

# Transferir arquivos CSV do seu computador local para o servidor
# (Execute estes comandos do seu computador local)
scp categories.csv stihl_app_user@143.198.33.61:/tmp/csv_data/
scp stihl_technologies.csv stihl_app_user@143.198.33.61:/tmp/csv_data/
scp campaigns.csv stihl_app_user@143.198.33.61:/tmp/csv_data/
scp products.csv stihl_app_user@143.198.33.61:/tmp/csv_data/
scp technical_specifications.csv stihl_app_user@143.198.33.61:/tmp/csv_data/
scp pricing.csv stihl_app_user@143.198.33.61:/tmp/csv_data/
scp tax_information.csv stihl_app_user@143.198.33.61:/tmp/csv_data/
scp product_relationships.csv stihl_app_user@143.198.33.61:/tmp/csv_data/

# Ajustar permissões (execute no servidor)
sudo chmod 644 /tmp/csv_data/*.csv
```

**Execução dos scripts SQL (na ordem correta):**

```bash
# 1. Criar estrutura das tabelas
PGPASSWORD=rBVm2mIQds3PneOy psql -h db.eclmgkajlhrstyyhejev.supabase.co -U postgres -d postgres -f 01_create_tables.sql

# 2. Criar funções especializadas para IA
PGPASSWORD=rBVm2mIQds3PneOy psql -h db.eclmgkajlhrstyyhejev.supabase.co -U postgres -d postgres -f 02_create_functions.sql

# 3. Importar dados dos arquivos CSV (NOVO)
PGPASSWORD=rBVm2mIQds3PneOy psql -h db.eclmgkajlhrstyyhejev.supabase.co -U postgres -d postgres -f 05_import_csv_data.sql

# 4. Configurar segurança e RLS
PGPASSWORD=rBVm2mIQds3PneOy psql -h db.eclmgkajlhrstyyhejev.supabase.co -U postgres -d postgres -f 04_security_rls.sql
```

**Observação importante:** O script `03_insert_data.sql` (dados de exemplo hardcoded) foi substituído pelo `05_import_csv_data.sql` que importa dados dos seus arquivos CSV normalizados. Isso oferece muito mais flexibilidade e permite trabalhar com volumes maiores de dados.

**Observações Importantes:**

-   A chave `service_role` (`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVjbG1na2FqbGhyc3R5eWhlamV2Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1NjY4ODM0MCwiZXhwIjoyMDcyMjY0MzQwfQ.XvRgFhWYRXLDXn7kF8ys-hXGK04XDRHzkB3KeS3ktKo`) deve ser usada com cautela, pois ela ignora as políticas de RLS. Ela é ideal para o backend da sua aplicação (onde a IA autônoma irá construir o banco de dados), mas nunca deve ser exposta no frontend ou em aplicações cliente.
-   Após a execução dos scripts, você pode verificar a estrutura do banco de dados e os dados inseridos navegando para a seção `Table Editor` ou `Authentication` no painel do Supabase.

Com o Supabase configurado, o próximo passo é preparar o seu servidor DigitalOcean para receber a aplicação Flask.



## 3. Preparação do Servidor DigitalOcean

Esta seção detalha os passos para preparar o seu droplet DigitalOcean com Ubuntu 24.04 LTS para hospedar a aplicação Flask. É crucial seguir estes passos para garantir um ambiente seguro e funcional.

### 3.1 Conectando ao Servidor via SSH

Você pode se conectar ao seu droplet usando o cliente SSH do seu terminal. Certifique-se de substituir `seu_usuario` pelo usuário que você configurou (geralmente `root` inicialmente) e `143.198.33.61` pelo IP público do seu droplet.

```bash
ssh seu_usuario@143.198.33.61
```

Se você estiver usando uma chave SSH, certifique-se de que ela esteja configurada corretamente no seu cliente SSH. Por exemplo:

```bash
ssh -i ~/.ssh/sua_chave_privada seu_usuario@143.198.33.61
```

### 3.2 Atualizando Pacotes do Sistema

É uma boa prática atualizar todos os pacotes do sistema para as versões mais recentes. Isso garante que você tenha as últimas correções de segurança e funcionalidades.

```bash
sudo apt update
sudo apt upgrade -y
sudo apt autoremove -y
```

### 3.3 Instalando Python e Dependências Essenciais

O Ubuntu 24.04 LTS já vem com Python 3.11 ou superior. Precisamos instalar o `pip` (gerenciador de pacotes Python) e algumas bibliotecas de desenvolvimento que são necessárias para compilar certas dependências Python (como `psycopg2`, que se conecta ao PostgreSQL).

```bash
sudo apt install -y python3-pip python3-venv build-essential libpq-dev
```

-   `python3-pip`: Instala o pip para Python 3.
-   `python3-venv`: Permite a criação de ambientes virtuais Python.
-   `build-essential`: Contém pacotes essenciais para compilação (gcc, g++, make, etc.).
-   `libpq-dev`: Bibliotecas de desenvolvimento para PostgreSQL, necessárias para o `psycopg2`.

### 3.4 Criando um Usuário Não-Root para a Aplicação (Recomendado)

É uma prática de segurança criar um usuário dedicado para a sua aplicação, em vez de rodá-la como `root`. Isso limita o impacto de possíveis vulnerabilidades.

```bash
sudo adduser stihl_app_user
sudo usermod -aG sudo stihl_app_user # Opcional: conceder acesso sudo temporário para configuração
```

Agora, você pode sair da sessão `root` e fazer login com o novo usuário:

```bash
exit
ssh stihl_app_user@143.198.33.61
```

### 3.5 Configurando o Firewall (UFW)

O Uncomplicated Firewall (UFW) é uma interface mais simples para gerenciar regras de firewall no Linux. Precisamos configurá-lo para permitir o tráfego SSH, HTTP e HTTPS.

```bash
sudo ufw allow OpenSSH
sudo ufw allow 'Nginx HTTP' # Será configurado mais tarde para Nginx
sudo ufw allow 'Nginx HTTPS' # Será configurado mais tarde para Nginx
sudo ufw enable
sudo ufw status
```

Verifique o status do firewall para confirmar que as regras estão ativas. Você deve ver as regras para `OpenSSH` ativas.

Com o servidor preparado, o próximo passo é implantar a aplicação Flask.



### 2.4 Limpeza de Estruturas Existentes no Supabase (Se Necessário)

Se você já possui tabelas ou dados no seu projeto Supabase que deseja remover para começar do zero, siga estas instruções. **Cuidado: esta operação é irreversível e apagará todos os dados e estruturas selecionados.**

#### Opção 1: Deletar Tabelas Individualmente via SQL Editor

Você pode deletar tabelas específicas usando comandos `DROP TABLE` no SQL Editor do Supabase. Certifique-se de deletar na ordem correta para evitar erros de dependência (tabelas filhas antes das tabelas pai).

```sql
-- Exemplo de exclusão de tabelas (ajuste conforme suas tabelas)
DROP TABLE IF EXISTS product_relationships CASCADE;
DROP TABLE IF EXISTS pricing CASCADE;
DROP TABLE IF EXISTS tax_information CASCADE;
DROP TABLE IF EXISTS technical_specifications CASCADE;
DROP TABLE IF EXISTS products CASCADE;
DROP TABLE IF EXISTS categories CASCADE;
-- Adicione aqui outras tabelas que você possa ter criado

-- Excluir funções (se existirem)
DROP FUNCTION IF EXISTS intelligent_product_search CASCADE;
DROP FUNCTION IF EXISTS get_product_recommendations CASCADE;
DROP FUNCTION IF EXISTS get_categories_hierarchy CASCADE;
DROP FUNCTION IF EXISTS get_price_ranges_by_category CASCADE;
DROP FUNCTION IF EXISTS get_product_by_code CASCADE;
-- Adicione aqui outras funções que você possa ter criado

-- Excluir views materializadas (se existirem)
DROP MATERIALIZED VIEW IF EXISTS mv_product_summary CASCADE;
-- Adicione aqui outras views materializadas que você possa ter criado

-- Excluir políticas RLS (se existirem)
-- As políticas RLS são automaticamente removidas com as tabelas, mas pode ser útil verificar
```

#### Opção 2: Resetar o Banco de Dados (Opção Mais Drástica)

O Supabase oferece uma opção para resetar completamente o banco de dados do seu projeto, o que apagará **TODAS** as tabelas, dados, funções e políticas RLS. Use esta opção com extrema cautela.

1.  No painel do Supabase, vá para `Project Settings` > `Database`.
2.  Role para baixo até a seção `Danger Zone`.
3.  Clique em `Reset Database`.
4.  Siga as instruções na tela para confirmar a operação. Você precisará digitar o nome do seu projeto para confirmar.

Após a limpeza, você pode prosseguir com a execução dos scripts SQL fornecidos na seção `2.3 Executando os Scripts SQL` para recriar a estrutura do zero.



### 3.6 Limpeza de Estruturas Existentes no Servidor (Se Necessário)

Se você já tentou implantar a aplicação ou outras estruturas no seu servidor DigitalOcean e deseja começar do zero, siga estas instruções para limpar o ambiente. **Cuidado: estas operações são irreversíveis e apagarão arquivos e configurações.**

#### 3.6.1 Remover Diretório da Aplicação

Se você já clonou o repositório ou criou um diretório para a aplicação, remova-o:

```bash
sudo rm -rf /home/stihl_app_user/stihl_ai_builder # Ou o caminho onde a aplicação foi clonada
```

#### 3.6.2 Parar e Desabilitar Serviços (Gunicorn/Nginx)

Se você já configurou e iniciou o Gunicorn ou Nginx para a aplicação, pare e desabilite os serviços para evitar conflitos:

```bash
sudo systemctl stop gunicorn_stihl_ai.service # Se você já criou este serviço
sudo systemctl disable gunicorn_stihl_ai.service
sudo rm /etc/systemd/system/gunicorn_stihl_ai.service

sudo systemctl stop nginx
sudo rm /etc/nginx/sites-available/stihl_ai # Se você já criou este arquivo de configuração
sudo rm /etc/nginx/sites-enabled/stihl_ai
sudo systemctl restart nginx
```

#### 3.6.3 Limpar Ambientes Virtuais e Dependências Python

Se você criou ambientes virtuais ou instalou dependências globalmente, pode removê-los:

```bash
# Remover ambiente virtual (se estiver dentro do diretório da aplicação)
rm -rf venv

# Se você instalou pacotes Python globalmente (NÃO RECOMENDADO EM PRODUÇÃO):
# pip uninstall <nome_do_pacote> # Para cada pacote instalado
```

#### 3.6.4 Limpar Logs e Outros Arquivos Temporários

```bash
sudo rm -rf /var/log/nginx/stihl_ai_access.log # Se você configurou logs específicos
sudo rm -rf /var/log/nginx/stihl_ai_error.log
```

Após a limpeza, você pode prosseguir com a implantação da aplicação Flask, começando do zero.



## 4. Implantação da Aplicação Flask

Com o servidor DigitalOcean preparado e o Supabase configurado, o próximo passo é implantar a aplicação Flask. Esta seção detalha como clonar o código, configurar o ambiente Python e testar a aplicação.

### 4.1 Clonando o Repositório da Aplicação

Primeiro, você precisará clonar o repositório da aplicação para o seu servidor. Assumindo que você está logado como o usuário `stihl_app_user` no diretório `/home/stihl_app_user/`:

```bash
cd /home/stihl_app_user/

# Opção 1: Se você transferiu o arquivo ZIP para o servidor
# Primeiro, crie o diretório do projeto se ele ainda não existir
sudo mkdir -p /home/stihl_app_user/ai-database-system/
sudo chown stihl_app_user:stihl_app_user /home/stihl_app_user/ai-database-system/

# Descompacte o arquivo ZIP para o diretório do projeto
unzip /home/stihl_app_user/comercial/stihl_ai_essential_files.zip -d /home/stihl_app_user/ai-database-system/

# Agora, navegue para o diretório do projeto
cd ai-database-system

# Opção 2: Se você preferir clonar de um repositório Git (após configurar SSH no GitHub)
# git clone https://github.com/stihl/ai-database-system.git # Substitua pelo URL real do seu repositório
# cd ai-database-system
```

**Observação:** Se o seu repositório for privado, você precisará configurar uma chave SSH no GitHub (ou serviço de hospedagem de código) para o seu usuário `stihl_app_user` no servidor. O `pasted_content.txt` que você forneceu contém uma chave SSH gerada, mas ela precisa ser adicionada ao seu GitHub. Se você não fez isso, siga os passos:

1.  No seu servidor, gere uma nova chave SSH para o usuário `stihl_app_user` (se ainda não tiver uma):
    ```bash
    ssh-keygen -t ed25519 -C "seu_email@exemplo.com" -f ~/.ssh/id_ed25519 -N ""
    ```
2.  Exiba a chave pública:
    ```bash
    cat ~/.ssh/id_ed25519.pub
    ```
3.  Copie a saída e adicione-a às configurações SSH do seu GitHub (ou Bitbucket/GitLab).

### 4.2 Criando e Ativando o Ambiente Virtual Python

É altamente recomendável usar um ambiente virtual para isolar as dependências do seu projeto de outras instalações Python no sistema. Isso evita conflitos e facilita o gerenciamento.

```bash
python3 -m venv venv
source venv/bin/activate
```

Você verá `(venv)` no início do seu prompt de comando, indicando que o ambiente virtual está ativo.

### 4.3 Instalando Dependências Python

Com o ambiente virtual ativo, instale todas as dependências listadas no arquivo `requirements.txt`.

```bash
pip install -r requirements.txt
```

### 4.4 Configurando Variáveis de Ambiente

As variáveis de ambiente essenciais para a aplicação devem ser configuradas. Em um ambiente de produção, é comum usar um arquivo `.env` ou configurar diretamente no serviço `systemd` do Gunicorn. Por enquanto, para testes, você pode exportá-las diretamente na sessão SSH.

**CUIDADO:** Nunca exponha chaves secretas em arquivos de configuração públicos ou no controle de versão.

```bash
export OPENAI_API_KEY="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"
export SUPABASE_URL="https://eclmgkajlhrstyyhejev.supabase.co"
export SUPABASE_ANON_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVjbG1na2FqbGhyc3R5eWhlamV2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY2ODgzNDAsImV4cCI6MjA3MjI2NDM0MH0.fvA7SpoofVp3iBqc4uYfQX49rp1MooLWfHC3uFM7-Bw"
export SUPABASE_SERVICE_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVjbG1na2FqbGhyc3R5eWhlamV2Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1NjY4ODM0MCwiZXhwIjoyMDcyMjY0MzQwfQ.XvRgFhWYRXLDXn7kF8ys-hXGK04XDRHzkB3KeS3ktKo"
export DATABASE_URL="postgresql://postgres:rBVm2mIQds3PneOy@db.eclmgkajlhrstyyhejev.supabase.co:5432/postgres"
export FLASK_ENV="production"
export SECRET_KEY="$(python3 -c 'import os; print(os.urandom(24).hex())')" # Gera uma chave aleatória
```

### 4.5 Testando a Aplicação Flask Localmente no Servidor

Antes de configurar o Gunicorn e Nginx, é importante verificar se a aplicação Flask funciona corretamente por si só. Certifique-se de estar no diretório raiz do projeto (`/home/stihl_app_user/ai-database-system/`).

```bash
cd src
flask run --host=0.0.0.0 --port=5000
```

Você deverá ver uma mensagem indicando que o servidor Flask está rodando. Se houver erros, eles serão exibidos no terminal. Verifique se as variáveis de ambiente foram configuradas corretamente e se não há erros de importação de módulos.

**Para testar o endpoint de saúde da API:**

Abra uma nova sessão SSH para o seu servidor (ou use `Ctrl+Z` para suspender o processo Flask e `bg` para rodá-lo em segundo plano, mas `Ctrl+C` para parar e iniciar em uma nova sessão é mais limpo para testes).

```bash
curl http://localhost:5000/api/search/test
```

Você deverá receber uma resposta JSON indicando que a API está funcionando. Se tudo estiver correto, você pode parar o servidor Flask (`Ctrl+C`) e prosseguir para a próxima fase de configuração do Gunicorn e Nginx.


## 5. Configuração do Nginx e Gunicorn

Para um ambiente de produção robusto, é essencial configurar um servidor WSGI (Gunicorn) para servir a aplicação Flask e um servidor web (Nginx) como proxy reverso. Esta configuração oferece melhor performance, segurança e capacidade de lidar com múltiplas requisições simultâneas.

### 5.1 Instalando e Configurando o Gunicorn

O Gunicorn (Green Unicorn) é um servidor WSGI Python que servirá a aplicação Flask. Primeiro, certifique-se de que o ambiente virtual está ativo e instale o Gunicorn:

```bash
cd /home/stihl_app_user/ai-database-system/
source venv/bin/activate
pip install gunicorn
```

#### 5.1.1 Testando o Gunicorn

Antes de criar o serviço systemd, teste se o Gunicorn consegue servir a aplicação corretamente:

```bash
cd src
gunicorn --workers 3 --bind 0.0.0.0:5000 main:app
```

Teste o endpoint novamente em uma nova sessão SSH:

```bash
curl http://localhost:5000/api/search/test
```

Se tudo estiver funcionando, pare o Gunicorn (`Ctrl+C`) e prossiga para criar o serviço systemd.

#### 5.1.2 Criando o Arquivo de Serviço Systemd para o Gunicorn

O systemd permitirá que o Gunicorn seja iniciado automaticamente na inicialização do sistema e seja gerenciado como um serviço. Crie o arquivo de serviço:

```bash
sudo nano /etc/systemd/system/gunicorn_stihl_ai.service
```

Adicione o seguinte conteúdo ao arquivo:

```ini
[Unit]
Description=Gunicorn instance to serve STIHL AI Application
After=network.target

[Service]
User=stihl_app_user
Group=www-data
WorkingDirectory=/home/stihl_app_user/ai-database-system/src
Environment="PATH=/home/stihl_app_user/ai-database-system/venv/bin"
Environment="OPENAI_API_KEY=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"
Environment="SUPABASE_URL=https://eclmgkajlhrstyyhejev.supabase.co"
Environment="SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVjbG1na2FqbGhyc3R5eWhlamV2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY2ODgzNDAsImV4cCI6MjA3MjI2NDM0MH0.fvA7SpoofVp3iBqc4uYfQX49rp1MooLWfHC3uFM7-Bw"
Environment="SUPABASE_SERVICE_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVjbG1na2FqbGhyc3R5eWhlamV2Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc1NjY4ODM0MCwiZXhwIjoyMDcyMjY0MzQwfQ.XvRgFhWYRXLDXn7kF8ys-hXGK04XDRHzkB3KeS3ktKo"
Environment="DATABASE_URL=postgresql://postgres:rBVm2mIQds3PneOy@db.eclmgkajlhrstyyhejev.supabase.co:5432/postgres"
Environment="FLASK_ENV=production"
Environment="SECRET_KEY=sua_chave_secreta_gerada_aqui"
ExecStart=/home/stihl_app_user/ai-database-system/venv/bin/gunicorn --workers 3 --bind unix:/home/stihl_app_user/ai-database-system/stihl_ai.sock -m 007 main:app
ExecReload=/bin/kill -s HUP $MAINPID
Restart=always

[Install]
WantedBy=multi-user.target
```

**Observações importantes:**
- Substitua `sua_chave_secreta_gerada_aqui` por uma chave secreta real. Você pode gerar uma usando: `python3 -c 'import os; print(os.urandom(24).hex())'`
- O Gunicorn está configurado para usar um socket Unix (`stihl_ai.sock`) em vez de uma porta TCP, o que é mais eficiente para comunicação com o Nginx.

#### 5.1.3 Habilitando e Iniciando o Serviço Gunicorn

```bash
sudo systemctl daemon-reload
sudo systemctl start gunicorn_stihl_ai.service
sudo systemctl enable gunicorn_stihl_ai.service
sudo systemctl status gunicorn_stihl_ai.service
```

Verifique se o serviço está rodando sem erros. Se houver problemas, você pode ver os logs com:

```bash
sudo journalctl -u gunicorn_stihl_ai.service
```

### 5.2 Instalando e Configurando o Nginx

O Nginx atuará como proxy reverso, direcionando requisições HTTP/HTTPS para o Gunicorn e servindo arquivos estáticos diretamente.

#### 5.2.1 Instalando o Nginx

```bash
sudo apt update
sudo apt install nginx
```

#### 5.2.2 Configurando o Nginx para a Aplicação STIHL AI

Crie um arquivo de configuração para o seu site:

```bash
sudo nano /etc/nginx/sites-available/stihl_ai
```

Adicione o seguinte conteúdo:

```nginx
server {
    listen 80;
    server_name 143.198.33.61; # Substitua pelo seu domínio se tiver um

    location / {
        include proxy_params;
        proxy_pass http://unix:/home/stihl_app_user/ai-database-system/stihl_ai.sock;
    }

    location /static {
        alias /home/stihl_app_user/ai-database-system/src/static;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # Configurações de segurança
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer-when-downgrade" always;
    add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;

    # Configurações de upload (para planilhas Excel)
    client_max_body_size 50M;
}
```

#### 5.2.3 Habilitando o Site e Testando a Configuração

```bash
sudo ln -s /etc/nginx/sites-available/stihl_ai /etc/nginx/sites-enabled
sudo nginx -t # Testa a configuração
sudo systemctl restart nginx
```

### 5.3 Configurando SSL/HTTPS com Certbot (Opcional, mas Recomendado)

Para um ambiente de produção, é altamente recomendável configurar HTTPS. O Certbot automatiza a obtenção e renovação de certificados SSL gratuitos do Let's Encrypt.

#### 5.3.1 Instalando o Certbot

```bash
sudo apt install certbot python3-certbot-nginx
```

#### 5.3.2 Obtendo um Certificado SSL

**Observação:** Para usar o Certbot, você precisa de um nome de domínio apontando para o IP do seu servidor. Se você só tem o IP público (`143.198.33.61`), pode pular esta seção por enquanto.

Se você tiver um domínio (ex: `stihl-ai.seudominio.com`):

```bash
sudo certbot --nginx -d stihl-ai.seudominio.com
```

O Certbot modificará automaticamente a configuração do Nginx para incluir SSL e redirecionamento HTTPS.

#### 5.3.3 Configurando Renovação Automática

```bash
sudo systemctl status certbot.timer
sudo certbot renew --dry-run # Testa a renovação
```

Com o Nginx e Gunicorn configurados, a aplicação estará acessível via IP público do servidor.


## 6. Testes de Integração e Validação

Com a aplicação implantada e os serviços configurados, é crucial realizar testes abrangentes para garantir que tudo está funcionando corretamente. Esta seção detalha os testes essenciais para validar a funcionalidade completa do sistema.

### 6.1 Testando Acesso à API via IP Público

Primeiro, teste se a aplicação está acessível externamente através do IP público do servidor.

#### 6.1.1 Teste Básico de Conectividade

```bash
# Do seu computador local ou de outro servidor
curl http://143.198.33.61/api/search/test
```

Você deve receber uma resposta JSON similar a:
```json
{
  "status": "success",
  "message": "STIHL AI Search API is running",
  "timestamp": "2025-09-05T12:00:00Z"
}
```

#### 6.1.2 Teste da Interface Web

Abra um navegador e acesse:
- `http://143.198.33.61/` - Interface principal da IA autônoma
- `http://143.198.33.61/search_demo.html` - Demo de busca inteligente

### 6.2 Testando a IA de Busca Inteligente

#### 6.2.1 Teste de Busca Simples

```bash
curl -X POST http://143.198.33.61/api/search/search \
  -H "Content-Type: application/json" \
  -d '{
    "query": "motosserra MS 162",
    "type": "natural_language",
    "limit": 5
  }'
```

#### 6.2.2 Teste de Busca com Filtros de Preço

```bash
curl -X POST http://143.198.33.61/api/search/search \
  -H "Content-Type: application/json" \
  -d '{
    "query": "motosserra elétrica até R$ 1500",
    "type": "natural_language",
    "filters": {
      "max_price": 1500,
      "category": "motosserras"
    },
    "limit": 10
  }'
```

#### 6.2.3 Teste de Busca por Compatibilidade

```bash
curl -X POST http://143.198.33.61/api/search/search \
  -H "Content-Type: application/json" \
  -d '{
    "query": "carburador da FS220",
    "type": "natural_language",
    "limit": 5
  }'
```

### 6.3 Testando a IA Autônoma para Construção de Banco de Dados

#### 6.3.1 Teste de Análise de Planilha

Prepare um arquivo Excel de teste pequeno e faça upload através da interface web ou teste via API:

```bash
curl -X POST http://143.198.33.61/api/ai/analyze-excel \
  -F "file=@/caminho/para/planilha_teste.xlsx"
```

#### 6.3.2 Teste de Validação de Conexão

```bash
curl -X GET http://143.198.33.61/api/ai/health
```

### 6.4 Testando Funcionalidades Específicas

#### 6.4.1 Teste de Recomendações

```bash
curl -X POST http://143.198.33.61/api/search/recommendations \
  -H "Content-Type: application/json" \
  -d '{
    "product_id": "uuid-de-um-produto-existente",
    "user_preferences": {
      "budget": 2000,
      "usage_type": "domestico"
    },
    "limit": 5
  }'
```

#### 6.4.2 Teste de Sugestões de Busca

```bash
curl -X GET "http://143.198.33.61/api/search/suggest?q=motoss"
```

#### 6.4.3 Teste de Analytics

```bash
curl -X GET http://143.198.33.61/api/search/analytics
```

### 6.5 Validação de Performance

#### 6.5.1 Teste de Carga Básico

Use uma ferramenta como `ab` (Apache Bench) para testar a capacidade de resposta:

```bash
# Instalar ab se necessário
sudo apt install apache2-utils

# Teste com 100 requisições, 10 simultâneas
ab -n 100 -c 10 http://143.198.33.61/api/search/test
```

#### 6.5.2 Monitoramento de Recursos

```bash
# Verificar uso de CPU e memória
htop

# Verificar logs do Gunicorn
sudo journalctl -u gunicorn_stihl_ai.service -f

# Verificar logs do Nginx
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

### 6.6 Testes de Segurança Básicos

#### 6.6.1 Verificação de Headers de Segurança

```bash
curl -I http://143.198.33.61/
```

Verifique se os headers de segurança estão presentes:
- `X-Frame-Options`
- `X-XSS-Protection`
- `X-Content-Type-Options`
- `Referrer-Policy`

#### 6.6.2 Teste de Upload de Arquivo

Teste o upload de arquivos grandes para verificar os limites configurados:

```bash
# Criar arquivo de teste de 60MB (deve falhar se limite for 50MB)
dd if=/dev/zero of=test_large.xlsx bs=1M count=60

curl -X POST http://143.198.33.61/api/ai/analyze-excel \
  -F "file=@test_large.xlsx"
```

### 6.7 Validação de Logs e Monitoramento

#### 6.7.1 Verificação de Logs de Aplicação

```bash
# Logs do sistema
sudo journalctl -u gunicorn_stihl_ai.service --since "1 hour ago"

# Logs do Nginx
sudo tail -100 /var/log/nginx/access.log
sudo tail -100 /var/log/nginx/error.log
```

#### 6.7.2 Verificação de Status dos Serviços

```bash
sudo systemctl status gunicorn_stihl_ai.service
sudo systemctl status nginx
sudo systemctl status ufw
```

### 6.8 Checklist de Validação Final

- [ ] API de busca responde corretamente via IP público
- [ ] Interface web carrega sem erros
- [ ] Busca em linguagem natural funciona
- [ ] Upload de planilhas funciona
- [ ] Recomendações são geradas corretamente
- [ ] Performance está dentro do esperado (< 500ms para buscas simples)
- [ ] Logs não mostram erros críticos
- [ ] Todos os serviços estão ativos e habilitados
- [ ] Headers de segurança estão configurados
- [ ] Limites de upload estão funcionando

Se todos os testes passarem, a aplicação está pronta para uso em produção!


## 7. Guia de Uso da IA de Busca e Exemplos Práticos

Com o sistema implantado e validado, esta seção fornece um guia abrangente sobre como utilizar efetivamente a IA de busca inteligente para responder a consultas em linguagem natural sobre produtos STIHL. O sistema foi projetado para compreender consultas complexas e fornecer respostas precisas e contextualizadas.

### 7.1 Compreendendo o Funcionamento da IA de Busca

A IA de busca inteligente do sistema STIHL utiliza processamento de linguagem natural avançado para interpretar consultas em português brasileiro. O sistema analisa a intenção do usuário, extrai entidades relevantes (como modelos, preços, especificações) e consulta o banco de dados de forma inteligente para fornecer respostas precisas e contextualizadas.

#### 7.1.1 Tipos de Consultas Suportadas

O sistema é capaz de processar diversos tipos de consultas, desde buscas simples por produtos específicos até consultas complexas envolvendo múltiplos critérios e relacionamentos entre produtos.

**Consultas por Produto Específico:**
O sistema reconhece modelos STIHL específicos e pode fornecer informações detalhadas sobre eles. Por exemplo, quando um usuário pergunta sobre "MS 162", o sistema identifica automaticamente que se trata de uma motosserra específica e retorna informações completas sobre especificações técnicas, preços e acessórios compatíveis.

**Consultas por Categoria e Tipo:**
O sistema compreende categorias amplas como "motosserra", "roçadeira", "soprador" e pode filtrar resultados baseado no tipo de equipamento. Consultas como "motosserra elétrica" ou "roçadeira a bateria" são processadas corretamente, identificando tanto a categoria quanto o tipo de alimentação.

**Consultas por Faixa de Preço:**
A IA é capaz de interpretar expressões de preço em linguagem natural, como "até R$ 1500", "entre R$ 1000 e R$ 3000", ou "motosserra barata". O sistema converte essas expressões em filtros numéricos precisos para consulta no banco de dados.

**Consultas por Uso Pretendido:**
O sistema compreende contextos de uso como "uso doméstico", "profissional", "poda de árvores", "limpeza de terreno" e pode recomendar produtos adequados para cada situação específica.

**Consultas sobre Compatibilidade e Acessórios:**
Uma das funcionalidades mais avançadas é a capacidade de responder sobre compatibilidade entre produtos e acessórios. Por exemplo, quando perguntado sobre "carburador da FS220", o sistema não apenas identifica o carburador específico, mas também lista outros equipamentos compatíveis.

### 7.2 Exemplos Práticos de Consultas e Respostas

#### 7.2.1 Consulta sobre Produto Específico

**Pergunta:** "Qual o valor do carburador da FS220?"

**Resposta Esperada do Sistema:**
```
Carburador para Roçadeira FS220 STIHL
Código: 4180-120-0610
Preço: R$ 285,00

Observação: Este carburador também é compatível com os seguintes equipamentos:
- FS200
- FS250
- FS300
- FS350

Especificações técnicas:
- Tipo: Carburador de membrana
- Combustível: Gasolina + óleo 2T
- Regulagem: Automática
```

**Como o Sistema Processa:**
1. Identifica "carburador" como tipo de produto/acessório
2. Reconhece "FS220" como modelo específico de roçadeira
3. Busca no banco de dados produtos relacionados
4. Retorna informações de preço, código e compatibilidade
5. Adiciona informações contextuais sobre especificações

#### 7.2.2 Consulta por Categoria com Filtro de Preço

**Pergunta:** "Motosserra elétrica até R$ 1500"

**Resposta Esperada do Sistema:**
```
Encontrei 3 motosserras elétricas dentro do seu orçamento:

1. STIHL MSE 141 C-Q
   Preço: R$ 1.299,00
   Código: 1141-200-0130
   Potência: 1.400W
   Peso: 4,1 kg
   Ideal para: Uso doméstico, poda leve

2. STIHL MSE 170 C-BQ
   Preço: R$ 1.450,00
   Código: 1170-200-0140
   Potência: 1.700W
   Peso: 4,2 kg
   Ideal para: Uso doméstico intensivo

3. STIHL MSE 190 C-BQ
   Preço: R$ 1.499,00
   Código: 1190-200-0150
   Potência: 1.900W
   Peso: 4,3 kg
   Ideal para: Uso semi-profissional

Todas incluem sistema de partida fácil e tensionamento rápido da corrente.
```

#### 7.2.3 Consulta sobre Uso Específico

**Pergunta:** "Qual motosserra para poda de árvores altas?"

**Resposta Esperada do Sistema:**
```
Para poda de árvores altas, recomendo as seguintes motosserras STIHL:

1. STIHL MS 194 T (Recomendada)
   Preço: R$ 2.850,00
   Código: 1194-200-0160
   Características especiais:
   - Design compacto para trabalho em altura
   - Peso reduzido: 3,0 kg
   - Motor 2-MIX de baixa emissão
   - Cabo traseiro para melhor controle

2. STIHL MS 201 T
   Preço: R$ 3.200,00
   Código: 1201-200-0170
   Características especiais:
   - Profissional para arboricultura
   - Sistema anti-vibração avançado
   - Peso: 3,7 kg
   - Alta potência para cortes precisos

Acessórios recomendados:
- Sabre de 30cm para maior alcance
- Corrente de baixo recuo para segurança
- Equipamentos de proteção individual (EPI)
```

#### 7.2.4 Consulta sobre Compatibilidade

**Pergunta:** "Que correntes servem na MS 250?"

**Resposta Esperada do Sistema:**
```
Para a motosserra STIHL MS 250, as correntes compatíveis são:

Correntes Originais STIHL:
1. Corrente Picco Micro 3 (PM3)
   Código: 3610-005-0052
   Preço: R$ 89,00
   Características: Baixo recuo, ideal uso doméstico

2. Corrente Rapid Micro 3 (RM3)
   Código: 3652-005-0052
   Preço: R$ 95,00
   Características: Corte rápido, uso semi-profissional

3. Corrente Rapid Super 3 (RS3)
   Código: 3624-005-0052
   Preço: R$ 105,00
   Características: Máxima performance, uso profissional

Especificações técnicas:
- Passo: 3/8" Picco
- Bitola: 1,3mm (0.050")
- Elos de acionamento: 52

Observação: Sempre utilize correntes originais STIHL para garantir performance e segurança ideais.
```

### 7.3 Integração com Sistemas de Mensageria

#### 7.3.1 Integração com Telegram

Para integrar o sistema com um bot do Telegram, você pode usar a API REST da aplicação. Aqui está um exemplo de como configurar um bot que responde a consultas sobre produtos STIHL:

**Configuração Básica do Bot Telegram:**

```python
import requests
import telegram
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters

# Token fornecido: 8439346525:AAElGYOzJjbXp6qInQqFnJRCNf8cfRXgqFw
TELEGRAM_TOKEN = "8439346525:AAElGYOzJjbXp6qInQqFnJRCNf8cfRXgqFw"
STIHL_AI_API_URL = "http://143.198.33.61/api/search/search"

def search_stihl_products(query):
    """Consulta a API do sistema STIHL AI"""
    payload = {
        "query": query,
        "type": "natural_language",
        "limit": 3
    }
    
    try:
        response = requests.post(STIHL_AI_API_URL, json=payload, timeout=10)
        if response.status_code == 200:
            return response.json()
        else:
            return {"error": "Erro na consulta"}
    except Exception as e:
        return {"error": f"Erro de conexão: {str(e)}"}

def handle_message(update, context):
    """Processa mensagens do usuário"""
    user_query = update.message.text
    
    # Consulta o sistema STIHL AI
    result = search_stihl_products(user_query)
    
    if "error" in result:
        response_text = "Desculpe, ocorreu um erro ao processar sua consulta. Tente novamente."
    elif result.get("success") and result.get("results"):
        response_text = format_search_results(result["results"])
    else:
        response_text = "Não encontrei produtos que correspondam à sua consulta. Tente reformular a pergunta."
    
    update.message.reply_text(response_text)

def format_search_results(results):
    """Formata os resultados para exibição no Telegram"""
    if not results:
        return "Nenhum produto encontrado."
    
    response = "🔍 **Produtos encontrados:**\n\n"
    
    for i, product in enumerate(results[:3], 1):
        response += f"**{i}. {product.get('name', 'Produto')}**\n"
        response += f"💰 Preço: R$ {product.get('price_value', 'N/A')}\n"
        response += f"📋 Código: {product.get('model', 'N/A')}\n"
        
        if product.get('description'):
            response += f"📝 {product['description'][:100]}...\n"
        
        if product.get('compatibility_info'):
            response += f"🔧 Compatível com: {product['compatibility_info']}\n"
        
        response += "\n"
    
    return response

def start_command(update, context):
    """Comando /start"""
    welcome_text = """
🤖 **Bem-vindo ao Consultor STIHL AI!**

Eu posso ajudar você a encontrar produtos STIHL e responder suas dúvidas sobre:
• Motosserras
• Roçadeiras  
• Sopradores
• Acessórios e peças

**Exemplos de perguntas:**
• "Qual o valor do carburador da FS220?"
• "Motosserra elétrica até R$ 1500"
• "Que correntes servem na MS 250?"

Digite sua pergunta e eu te ajudo! 🛠️
    """
    update.message.reply_text(welcome_text, parse_mode='Markdown')

# Configuração do bot
def main():
    updater = Updater(TELEGRAM_TOKEN, use_context=True)
    dispatcher = updater.dispatcher
    
    dispatcher.add_handler(CommandHandler("start", start_command))
    dispatcher.add_handler(MessageHandler(Filters.text & ~Filters.command, handle_message))
    
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
```

#### 7.3.2 Integração com WhatsApp Business API

Para integração com WhatsApp, você pode usar a API do WhatsApp Business ou serviços como Twilio:

```python
from twilio.rest import Client
import requests

class WhatsAppStihlBot:
    def __init__(self, account_sid, auth_token, whatsapp_number):
        self.client = Client(account_sid, auth_token)
        self.whatsapp_number = whatsapp_number
        self.stihl_api_url = "http://143.198.33.61/api/search/search"
    
    def process_message(self, from_number, message_body):
        """Processa mensagem recebida do WhatsApp"""
        
        # Consulta a IA STIHL
        result = self.search_products(message_body)
        
        # Formata resposta
        response = self.format_response(result)
        
        # Envia resposta
        self.send_message(from_number, response)
    
    def search_products(self, query):
        """Consulta a API STIHL AI"""
        payload = {
            "query": query,
            "type": "natural_language",
            "limit": 3
        }
        
        try:
            response = requests.post(self.stihl_api_url, json=payload)
            return response.json()
        except Exception as e:
            return {"error": str(e)}
    
    def format_response(self, result):
        """Formata resposta para WhatsApp"""
        if "error" in result:
            return "Desculpe, ocorreu um erro. Tente novamente."
        
        if not result.get("results"):
            return "Não encontrei produtos para sua consulta. Tente reformular a pergunta."
        
        response = "🔍 *Produtos encontrados:*\n\n"
        
        for product in result["results"][:2]:  # Limite para WhatsApp
            response += f"*{product.get('name')}*\n"
            response += f"💰 R$ {product.get('price_value')}\n"
            response += f"📋 Código: {product.get('model')}\n\n"
        
        response += "Precisa de mais informações? Digite outra pergunta!"
        return response
    
    def send_message(self, to_number, message):
        """Envia mensagem via WhatsApp"""
        self.client.messages.create(
            body=message,
            from_=f'whatsapp:{self.whatsapp_number}',
            to=f'whatsapp:{to_number}'
        )
```

#### 7.3.3 Integração com Chat Web

Para um chat web integrado ao seu site, você pode usar a API diretamente via JavaScript:

```html
<!DOCTYPE html>
<html>
<head>
    <title>Chat STIHL AI</title>
    <style>
        .chat-container {
            max-width: 600px;
            margin: 0 auto;
            border: 1px solid #ddd;
            border-radius: 10px;
            height: 500px;
            display: flex;
            flex-direction: column;
        }
        
        .chat-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            background-color: #f9f9f9;
        }
        
        .message {
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 10px;
            max-width: 80%;
        }
        
        .user-message {
            background-color: #007bff;
            color: white;
            margin-left: auto;
        }
        
        .bot-message {
            background-color: white;
            border: 1px solid #ddd;
        }
        
        .chat-input {
            display: flex;
            padding: 20px;
            border-top: 1px solid #ddd;
        }
        
        .chat-input input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-right: 10px;
        }
        
        .chat-input button {
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="chat-container">
        <div class="chat-messages" id="chatMessages">
            <div class="message bot-message">
                <strong>🤖 Consultor STIHL AI</strong><br>
                Olá! Posso ajudar você a encontrar produtos STIHL. 
                Faça sua pergunta sobre motosserras, roçadeiras, acessórios e muito mais!
            </div>
        </div>
        
        <div class="chat-input">
            <input type="text" id="messageInput" placeholder="Digite sua pergunta..." 
                   onkeypress="handleKeyPress(event)">
            <button onclick="sendMessage()">Enviar</button>
        </div>
    </div>

    <script>
        const API_URL = 'http://143.198.33.61/api/search/search';
        
        function addMessage(content, isUser = false) {
            const messagesContainer = document.getElementById('chatMessages');
            const messageDiv = document.createElement('div');
            messageDiv.className = `message ${isUser ? 'user-message' : 'bot-message'}`;
            messageDiv.innerHTML = content;
            messagesContainer.appendChild(messageDiv);
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
        
        function handleKeyPress(event) {
            if (event.key === 'Enter') {
                sendMessage();
            }
        }
        
        async function sendMessage() {
            const input = document.getElementById('messageInput');
            const message = input.value.trim();
            
            if (!message) return;
            
            // Adiciona mensagem do usuário
            addMessage(message, true);
            input.value = '';
            
            // Mostra indicador de digitação
            addMessage('🤖 Digitando...');
            
            try {
                const response = await fetch(API_URL, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        query: message,
                        type: 'natural_language',
                        limit: 3
                    })
                });
                
                const result = await response.json();
                
                // Remove indicador de digitação
                const messages = document.getElementById('chatMessages');
                messages.removeChild(messages.lastChild);
                
                // Formata e adiciona resposta
                const formattedResponse = formatSearchResults(result);
                addMessage(formattedResponse);
                
            } catch (error) {
                // Remove indicador de digitação
                const messages = document.getElementById('chatMessages');
                messages.removeChild(messages.lastChild);
                
                addMessage('Desculpe, ocorreu um erro. Tente novamente.');
            }
        }
        
        function formatSearchResults(result) {
            if (!result.success || !result.results || result.results.length === 0) {
                return 'Não encontrei produtos para sua consulta. Tente reformular a pergunta.';
            }
            
            let response = '<strong>🔍 Produtos encontrados:</strong><br><br>';
            
            result.results.forEach((product, index) => {
                response += `<strong>${index + 1}. ${product.name || 'Produto'}</strong><br>`;
                response += `💰 Preço: R$ ${product.price_value || 'N/A'}<br>`;
                response += `📋 Código: ${product.model || 'N/A'}<br>`;
                
                if (product.description) {
                    response += `📝 ${product.description.substring(0, 100)}...<br>`;
                }
                
                if (product.compatibility_info) {
                    response += `🔧 Compatível com: ${product.compatibility_info}<br>`;
                }
                
                response += '<br>';
            });
            
            return response;
        }
    </script>
</body>
</html>
```

### 7.4 Melhores Práticas para Uso da IA

#### 7.4.1 Formulação de Consultas Efetivas

Para obter os melhores resultados da IA de busca, é importante formular consultas de forma clara e específica. Consultas bem estruturadas produzem respostas mais precisas e úteis.

**Seja Específico com Modelos:**
Em vez de perguntar "motosserra STIHL", especifique o modelo quando possível: "MS 250" ou "MSE 141". Isso permite que o sistema forneça informações mais detalhadas e precisas.

**Use Contexto de Uso:**
Inclua informações sobre o uso pretendido: "motosserra para uso doméstico", "roçadeira profissional", "equipamento para jardinagem". Isso ajuda o sistema a recomendar produtos mais adequados.

**Especifique Critérios de Preço:**
Quando o orçamento for um fator importante, inclua faixas de preço específicas: "até R$ 2000", "entre R$ 1500 e R$ 3000". Isso filtra automaticamente os resultados.

#### 7.4.2 Interpretação de Respostas

As respostas da IA são estruturadas para fornecer informações completas e contextualizadas. Compreender a estrutura das respostas ajuda a extrair o máximo valor das consultas.

**Informações de Produto:**
Cada produto retornado inclui nome, código, preço e especificações técnicas relevantes. O código do produto é especialmente importante para pedidos e referências.

**Informações de Compatibilidade:**
Quando relevante, o sistema inclui informações sobre compatibilidade entre produtos, acessórios e peças de reposição. Isso é particularmente útil para manutenção e upgrades.

**Recomendações Contextuais:**
O sistema frequentemente inclui recomendações adicionais baseadas no contexto da consulta, como acessórios complementares ou produtos similares em diferentes faixas de preço.

#### 7.4.3 Limitações e Considerações

É importante compreender as limitações do sistema para usar a IA de forma efetiva e realista.

**Dados Baseados na Planilha:**
As informações retornadas são baseadas nos dados da planilha fornecida. Produtos não incluídos na planilha original não aparecerão nos resultados.

**Preços e Disponibilidade:**
Os preços mostrados são sugeridos e podem variar conforme região, revendedor e disponibilidade. Sempre confirme preços e disponibilidade com revendedores autorizados.

**Informações Técnicas:**
Embora o sistema forneça especificações técnicas detalhadas, para aplicações críticas ou especializadas, consulte sempre a documentação técnica oficial STIHL.


## 8. Conclusão e Próximos Passos

### 8.1 Resumo do Sistema Implantado

Com a conclusão deste guia, você agora possui um sistema completo e funcional de banco de dados inteligente STIHL com IA autônoma implantado em seu servidor DigitalOcean. O sistema oferece capacidades avançadas de busca em linguagem natural e construção automática de banco de dados, representando uma solução moderna e eficiente para gerenciamento de catálogos de produtos.

**Componentes Principais Implantados:**

O sistema implantado consiste em uma arquitetura robusta e escalável que integra múltiplas tecnologias modernas. No núcleo do sistema está a aplicação Flask que serve como backend principal, hospedando tanto a IA autônoma para construção de banco de dados quanto o motor de busca inteligente. Esta aplicação está configurada para rodar através do Gunicorn, um servidor WSGI de alta performance, garantindo estabilidade e capacidade de lidar com múltiplas requisições simultâneas.

O banco de dados PostgreSQL hospedado no Supabase fornece a base de dados persistente, configurado com estruturas otimizadas para busca e relacionamentos complexos entre produtos. As políticas de Row Level Security (RLS) implementadas garantem acesso controlado e seguro aos dados, enquanto as funções SQL especializadas otimizam as consultas da IA.

O servidor web Nginx atua como proxy reverso, fornecendo uma camada adicional de segurança e performance. Ele gerencia requisições HTTP/HTTPS, serve arquivos estáticos eficientemente e implementa headers de segurança essenciais para um ambiente de produção.

**Funcionalidades Principais Disponíveis:**

A IA de busca inteligente representa o coração funcional do sistema, capaz de processar consultas em linguagem natural em português brasileiro. O sistema compreende contextos complexos, extrai intenções do usuário e fornece respostas precisas e contextualizadas sobre produtos STIHL. A capacidade de interpretar consultas sobre compatibilidade, preços, especificações técnicas e uso pretendido torna o sistema extremamente versátil para diferentes tipos de usuários.

A IA autônoma para construção de banco de dados oferece uma funcionalidade revolucionária que permite a criação automática de estruturas de banco de dados a partir de planilhas Excel. Esta funcionalidade elimina a necessidade de intervenção manual especializada, reduzindo drasticamente o tempo necessário para implementar novos catálogos de produtos.

O sistema de APIs RESTful fornece integração flexível com sistemas externos, permitindo que a funcionalidade de busca inteligente seja incorporada em websites, aplicativos móveis, bots de Telegram, sistemas de WhatsApp e outras plataformas de comunicação.

### 8.2 Benefícios Alcançados

**Eficiência Operacional:**

A implementação do sistema resulta em ganhos significativos de eficiência operacional. A capacidade de responder automaticamente a consultas sobre produtos elimina a necessidade de consultas manuais a catálogos ou bases de dados, reduzindo o tempo de resposta de minutos para segundos. Para equipes de vendas e suporte técnico, isso representa uma melhoria substancial na produtividade e qualidade do atendimento.

A IA autônoma para construção de banco de dados transforma um processo que tradicionalmente levaria dias ou semanas em uma operação de poucos minutos. Isso é particularmente valioso para empresas que precisam atualizar frequentemente seus catálogos de produtos ou expandir para novos mercados.

**Melhoria na Experiência do Cliente:**

Clientes e usuários finais se beneficiam de uma experiência de busca significativamente melhorada. A capacidade de fazer perguntas em linguagem natural, como "qual o valor do carburador da FS220?", e receber respostas completas e contextualizadas representa um avanço substancial em relação a sistemas tradicionais de busca por palavras-chave.

A informação sobre compatibilidade entre produtos, incluída automaticamente nas respostas, ajuda clientes a tomar decisões mais informadas e reduz a probabilidade de compras inadequadas ou incompatíveis.

**Escalabilidade e Flexibilidade:**

A arquitetura implementada é altamente escalável, capaz de lidar com crescimento tanto em volume de dados quanto em número de usuários. O uso de tecnologias modernas como PostgreSQL, Nginx e Gunicorn garante que o sistema possa crescer conforme as necessidades da organização.

A flexibilidade do sistema permite integração com múltiplas plataformas e canais de comunicação, desde websites corporativos até bots de mensageria, oferecendo uma experiência consistente em todos os pontos de contato com o cliente.

### 8.3 Próximos Passos Recomendados

**Monitoramento e Otimização Contínua:**

Com o sistema em produção, é essencial implementar um programa de monitoramento contínuo para garantir performance ótima e identificar oportunidades de melhoria. Recomenda-se configurar alertas automáticos para métricas críticas como tempo de resposta da API, uso de recursos do servidor e taxa de erro.

A análise regular dos logs de busca pode revelar padrões de uso e consultas frequentes, permitindo otimizações direcionadas no algoritmo de busca e na estrutura do banco de dados. Considere implementar ferramentas de analytics mais avançadas para obter insights sobre comportamento dos usuários e eficácia das respostas.

**Expansão de Funcionalidades:**

O sistema atual fornece uma base sólida para expansões futuras. Considere implementar funcionalidades adicionais como busca por imagens, onde usuários podem fazer upload de fotos de produtos para identificação automática. A integração com sistemas de realidade aumentada pode permitir visualização de produtos em contexto real.

A implementação de um sistema de feedback dos usuários pode ajudar a melhorar continuamente a qualidade das respostas da IA. Considere adicionar funcionalidades de avaliação de respostas e aprendizado baseado em feedback para refinamento automático do sistema.

**Integração com Sistemas Corporativos:**

Para maximizar o valor do sistema, considere integrações mais profundas com sistemas corporativos existentes. A conexão com sistemas ERP pode permitir informações em tempo real sobre disponibilidade de estoque e preços dinâmicos. A integração com sistemas CRM pode personalizar respostas baseadas no histórico e perfil do cliente.

A implementação de APIs para sistemas de e-commerce pode automatizar a sincronização de catálogos de produtos e facilitar a manutenção de múltiplas plataformas de venda.

**Expansão Geográfica e de Idiomas:**

O sistema atual está otimizado para português brasileiro, mas a arquitetura suporta expansão para outros idiomas e mercados. Considere implementar suporte para espanhol e inglês para expansão internacional. A localização de preços, moedas e especificações técnicas pode facilitar a entrada em novos mercados.

### 8.4 Manutenção e Suporte Contínuo

**Atualizações de Segurança:**

Mantenha o sistema atualizado com as últimas correções de segurança para todos os componentes. Estabeleça um cronograma regular para atualizações do sistema operacional, dependências Python, e configurações de segurança. Monitore boletins de segurança para PostgreSQL, Nginx e outras tecnologias utilizadas.

Considere implementar um ambiente de staging para testar atualizações antes de aplicá-las em produção. Isso minimiza o risco de interrupções e permite validação completa de funcionalidades após atualizações.

**Backup e Recuperação:**

Implemente uma estratégia robusta de backup que inclua tanto dados do banco de dados quanto arquivos de configuração da aplicação. Configure backups automáticos diários com retenção apropriada e teste regularmente os procedimentos de recuperação.

Considere implementar replicação geográfica do banco de dados para maior resiliência e capacidade de recuperação em caso de desastres. O Supabase oferece opções de backup automático que devem ser configuradas adequadamente.

**Documentação e Treinamento:**

Mantenha documentação atualizada sobre configurações, procedimentos operacionais e troubleshooting. Isso é essencial para garantir continuidade operacional e facilitar transferência de conhecimento para novos membros da equipe.

Desenvolva materiais de treinamento para usuários finais, focando em como formular consultas efetivas e interpretar respostas da IA. Isso maximiza o valor percebido do sistema e reduz tickets de suporte.

### 8.5 Considerações de Compliance e Governança

**Proteção de Dados:**

Garanta que o sistema esteja em conformidade com regulamentações de proteção de dados aplicáveis, incluindo LGPD no Brasil. Implemente políticas claras de retenção de dados e procedimentos para atender solicitações de usuários relacionadas aos seus dados pessoais.

Considere implementar anonização de logs de consulta para proteger a privacidade dos usuários enquanto mantém capacidade de análise para melhorias do sistema.

**Auditoria e Compliance:**

Mantenha registros detalhados de todas as operações críticas do sistema para fins de auditoria. Isso inclui logs de acesso, modificações de dados e operações administrativas. Configure alertas para atividades suspeitas ou não autorizadas.

Estabeleça procedimentos claros para revisão regular de acessos e permissões, garantindo que apenas usuários autorizados tenham acesso apropriado ao sistema.

### 8.6 Métricas de Sucesso e KPIs

**Indicadores de Performance Técnica:**

Monitore métricas técnicas chave como tempo de resposta médio da API (meta: < 500ms), disponibilidade do sistema (meta: > 99.5%), e taxa de erro (meta: < 1%). Estas métricas fornecem indicadores objetivos da saúde técnica do sistema.

Acompanhe o crescimento no volume de consultas e a capacidade do sistema de escalar conforme a demanda. Isso ajuda a planejar upgrades de infraestrutura proativamente.

**Indicadores de Satisfação do Usuário:**

Implemente mecanismos para medir satisfação do usuário, como pesquisas periódicas ou sistemas de avaliação de respostas. Meta recomendada: > 85% de satisfação geral.

Monitore métricas de engajamento como número de consultas por usuário, tempo de sessão e taxa de retorno. Estas métricas indicam o valor percebido do sistema pelos usuários.

**Indicadores de Impacto no Negócio:**

Meça o impacto do sistema em métricas de negócio relevantes, como redução no tempo de atendimento ao cliente, aumento na taxa de conversão de vendas, ou redução em tickets de suporte relacionados a produtos.

Calcule o ROI do sistema considerando economias operacionais, aumento de receita e redução de custos de suporte. Isso justifica o investimento e orienta decisões sobre expansões futuras.

### 8.7 Considerações Finais

A implementação bem-sucedida deste sistema de banco de dados inteligente STIHL com IA autônoma representa um investimento significativo em tecnologia moderna que posicionará sua organização na vanguarda da inovação em gestão de catálogos de produtos. O sistema não apenas resolve desafios operacionais imediatos, mas também fornece uma plataforma flexível para crescimento e inovação futuros.

O sucesso a longo prazo do sistema dependerá da adoção efetiva pelos usuários, manutenção adequada da infraestrutura e evolução contínua das funcionalidades baseada em feedback e necessidades emergentes. Com o comprometimento adequado com estes aspectos, o sistema continuará fornecendo valor substancial e retorno sobre investimento por muitos anos.

A tecnologia implementada representa o estado da arte em sistemas de busca inteligente e automação de banco de dados, posicionando sua organização para aproveitar futuras inovações em inteligência artificial e processamento de linguagem natural. O investimento em capacidades técnicas internas e parcerias estratégicas será crucial para maximizar o potencial desta plataforma tecnológica avançada.

---

**Desenvolvido por:** Manus AI  
**Data de conclusão:** 05 de Setembro de 2025  
**Versão do guia:** 1.0.0  

Para suporte técnico ou dúvidas sobre implementação, consulte a documentação técnica completa ou entre em contato com a equipe de desenvolvimento.

