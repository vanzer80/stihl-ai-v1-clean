"""
Aplicação Principal STIHL AI v5
===============================

Sistema completo de IA para busca inteligente de produtos STIHL,
adaptado para a nova estrutura de banco de dados v5.

Funcionalidades:
- API REST para busca inteligente
- Interface web para demonstração
- Integração com OpenAI GPT-4
- Cache inteligente para performance
- Sistema de analytics e monitoramento

Autor: Manus AI
Data: 2025-09-08
Versão: 5.0
"""

import os
import logging
from datetime import datetime
from flask import Flask, render_template, jsonify, request, send_from_directory
from flask_cors import CORS
import psycopg2
from psycopg2.extras import RealDictCursor

# Importar blueprints e módulos
from routes.search_api_v5 import search_bp, init_search_engine

def create_app():
    """
    Factory function para criar a aplicação Flask
    
    Returns:
        Flask: Instância da aplicação configurada
    """
    app = Flask(__name__)
    
    # Configurações da aplicação
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
    app.config['DEBUG'] = os.getenv('FLASK_ENV') == 'development'
    app.config['DATABASE_URL'] = os.getenv('DATABASE_URL')
    app.config['OPENAI_API_KEY'] = os.getenv('OPENAI_API_KEY')
    app.config['SUPABASE_URL'] = os.getenv('SUPABASE_URL')
    app.config['SUPABASE_ANON_KEY'] = os.getenv('SUPABASE_ANON_KEY')
    app.config['SUPABASE_SERVICE_KEY'] = os.getenv('SUPABASE_SERVICE_KEY')
    
    # Configurar logging
    if not app.debug:
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s %(levelname)s %(name)s %(message)s'
        )
    
    # Configurar CORS para permitir requisições de qualquer origem
    CORS(app, resources={
        r"/api/*": {
            "origins": "*",
            "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
            "allow_headers": ["Content-Type", "Authorization"]
        }
    })
    
    # Registrar blueprints
    app.register_blueprint(search_bp)
    
    # Inicializar sistema de busca
    if app.config['DATABASE_URL']:
        try:
            init_search_engine(app.config['DATABASE_URL'])
            app.logger.info("Sistema de busca inteligente inicializado com sucesso")
        except Exception as e:
            app.logger.error(f"Erro ao inicializar sistema de busca: {e}")
    else:
        app.logger.warning("DATABASE_URL não configurada - sistema de busca não inicializado")
    
    return app

# Criar instância da aplicação
app = create_app()

@app.route('/')
def index():
    """Página inicial com interface de demonstração"""
    return render_template('index.html')

@app.route('/search-demo')
def search_demo():
    """Página de demonstração da busca inteligente"""
    return render_template('search_demo.html')

@app.route('/api/health')
def api_health():
    """Endpoint de verificação de saúde da aplicação"""
    try:
        # Verificar conexão com banco de dados
        database_status = False
        if app.config['DATABASE_URL']:
            try:
                conn = psycopg2.connect(app.config['DATABASE_URL'])
                conn.close()
                database_status = True
            except Exception:
                pass
        
        health_data = {
            'status': 'healthy',
            'timestamp': datetime.now().isoformat(),
            'version': '5.0',
            'environment': os.getenv('FLASK_ENV', 'production'),
            'components': {
                'database': database_status,
                'openai': bool(app.config['OPENAI_API_KEY']),
                'supabase': bool(app.config['SUPABASE_URL'])
            }
        }
        
        return jsonify(health_data)
        
    except Exception as e:
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 500

@app.route('/api/config')
def api_config():
    """Endpoint para obter configurações públicas da aplicação"""
    config_data = {
        'version': '5.0',
        'environment': os.getenv('FLASK_ENV', 'production'),
        'features': {
            'intelligent_search': True,
            'natural_language_processing': bool(app.config['OPENAI_API_KEY']),
            'product_recommendations': True,
            'compatibility_search': True,
            'campaign_products': True,
            'price_analysis': True
        },
        'api_endpoints': {
            'search': '/api/search/search',
            'product_by_code': '/api/search/product/{code}',
            'compatible_products': '/api/search/compatible/{model}',
            'recommendations': '/api/search/recommendations',
            'campaigns': '/api/search/campaigns',
            'price_ranges': '/api/search/price-ranges',
            'suggestions': '/api/search/suggest',
            'analytics': '/api/search/analytics'
        }
    }
    
    return jsonify(config_data)

@app.route('/favicon.ico')
def favicon():
    """Serve favicon"""
    return send_from_directory(
        os.path.join(app.root_path, 'static'),
        'favicon.ico',
        mimetype='image/vnd.microsoft.icon'
    )

@app.errorhandler(404)
def not_found_error(error):
    """Handler para erro 404"""
    if request.path.startswith('/api/'):
        return jsonify({
            'error': 'Endpoint não encontrado',
            'message': 'Verifique a URL da API',
            'available_endpoints': [
                '/api/health',
                '/api/config',
                '/api/search/search',
                '/api/search/product/{code}',
                '/api/search/compatible/{model}',
                '/api/search/recommendations',
                '/api/search/campaigns',
                '/api/search/price-ranges',
                '/api/search/suggest',
                '/api/search/analytics'
            ]
        }), 404
    else:
        return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    """Handler para erro 500"""
    if request.path.startswith('/api/'):
        return jsonify({
            'error': 'Erro interno do servidor',
            'message': 'Tente novamente mais tarde'
        }), 500
    else:
        return render_template('500.html'), 500

@app.before_request
def log_request_info():
    """Log de informações da requisição (apenas em debug)"""
    if app.debug:
        app.logger.debug(f"Request: {request.method} {request.url}")
        if request.is_json:
            app.logger.debug(f"JSON Body: {request.get_json()}")

@app.after_request
def after_request(response):
    """Adicionar headers de segurança e CORS"""
    # Headers de segurança
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    
    # Headers CORS adicionais para APIs
    if request.path.startswith('/api/'):
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
    
    return response

if __name__ == '__main__':
    # Configurações para execução direta
    port = int(os.getenv('PORT', 5000))
    host = os.getenv('HOST', '0.0.0.0')
    debug = os.getenv('FLASK_ENV') == 'development'
    
    app.logger.info(f"Iniciando STIHL AI v5 em {host}:{port}")
    app.logger.info(f"Modo debug: {debug}")
    app.logger.info(f"Banco de dados configurado: {bool(app.config['DATABASE_URL'])}")
    app.logger.info(f"OpenAI configurado: {bool(app.config['OPENAI_API_KEY'])}")
    app.logger.info(f"Supabase configurado: {bool(app.config['SUPABASE_URL'])}")
    
    app.run(
        host=host,
        port=port,
        debug=debug,
        threaded=True
    )

